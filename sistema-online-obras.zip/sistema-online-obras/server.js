const express = require('express');
const mysql = require('mysql2');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const cors = require('cors');
const path = require('path');

const app = express();
const SECRET_KEY = 'sua_chave_secreta_super_segura_aqui';

app.use(express.json());
app.use(cors());

// Servir o frontend estático
app.use(express.static(path.join(__dirname, 'public')));

// ==========================================
// CONEXÃO COM O MYSQL DA HOSTINGER
// ==========================================
const db = mysql.createConnection({
  host: 'srv2023.hstgr.io',           // Geralmente localhost na Hostinger
  user: 'u559698905_GESTAO_GPS',     // Ex: u123456789_admin
  password: 'Amergdf6',   // A senha que você criou no painel
  database: 'u559698905_ONLINE_BANCO'    // Ex: u123456789_obras
});

db.connect((err) => {
  if (err) {
    console.error('Erro ao conectar ao MySQL da Hostinger:', err.message);
  } else {
    console.log('Conectado com sucesso ao MySQL da Hostinger!');
    criarTabelas();
  }
});

// Criar Tabelas Automáticas no MySQL caso não existam
function criarTabelas() {
  db.query(`CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) UNIQUE,
    password VARCHAR(255)
  )`);

  db.query(`CREATE TABLE IF NOT EXISTS empreiteiros (
    id INT AUTO_INCREMENT PRIMARY KEY,
    userId INT,
    nome VARCHAR(255)
  )`);

  db.query(`CREATE TABLE IF NOT EXISTS obras (
    id INT AUTO_INCREMENT PRIMARY KEY,
    userId INT,
    nome VARCHAR(255),
    areaExecucao VARCHAR(255),
    data VARCHAR(50),
    cep VARCHAR(20),
    endereco TEXT,
    complemento TEXT,
    valorTotal DECIMAL(10,2),
    empreiteiro VARCHAR(255),
    etapas TEXT
  )`);

  db.query(`CREATE TABLE IF NOT EXISTS medicoes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    userId INT,
    empreiteiro VARCHAR(255),
    obraId VARCHAR(50),
    obraNome VARCHAR(255),
    data VARCHAR(50),
    valorTotalPagamento DECIMAL(10,2),
    etapas TEXT
  )`);

  db.query(`CREATE TABLE IF NOT EXISTS cronogramas (
    userId INT PRIMARY KEY,
    dados TEXT
  )`);
}

// Middleware de Autenticação JWT
function verificarToken(req, res, next) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  if (!token) return res.status(401).json({ erro: 'Acesso negado. Token não fornecido.' });

  jwt.verify(token, SECRET_KEY, (err, user) => {
    if (err) return res.status(403).json({ erro: 'Token inválido ou expirado.' });
    req.user = user;
    next();
  });
}

// --- ROTAS DE AUTENTICAÇÃO ---
app.post('/api/register', async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) return res.status(400).json({ erro: 'E-mail e senha obrigatórios.' });

  try {
    const hashedPassword = await bcrypt.hash(password, 10);
    db.query(`INSERT INTO users (email, password) VALUES (?, ?)`, [email, hashedPassword], (err) => {
      if (err) return res.status(400).json({ erro: 'E-mail já cadastrado.' });
      res.json({ mensagem: 'Usuário cadastrado com sucesso!' });
    });
  } catch (e) {
    res.status(500).json({ erro: 'Erro no servidor.' });
  }
});

app.post('/api/login', (req, res) => {
  const { email, password } = req.body;
  db.query(`SELECT * FROM users WHERE email = ?`, [email], async (err, results) => {
    if (err || results.length === 0) return res.status(400).json({ erro: 'Usuário ou senha inválidos.' });

    const user = results[0];
    const senhaValida = await bcrypt.compare(password, user.password);
    if (!senhaValida) return res.status(400).json({ erro: 'Usuário ou senha inválidos.' });

    const token = jwt.sign({ userId: user.id, email: user.email }, SECRET_KEY, { expiresIn: '7d' });
    res.json({ token, email: user.email });
  });
});

// --- ROTAS DE DADOS (ISOLADAS POR USUÁRIO) ---

// Empreiteiros
app.get('/api/empreiteiros', verificarToken, (req, res) => {
  db.query(`SELECT * FROM empreiteiros WHERE userId = ?`, [req.user.userId], (err, rows) => {
    if (err) return res.status(500).json({ erro: err.message });
    res.json(rows);
  });
});

app.post('/api/empreiteiros', verificarToken, (req, res) => {
  const { nome } = req.body;
  db.query(`INSERT INTO empreiteiros (userId, nome) VALUES (?, ?)`, [req.user.userId, nome], (err, result) => {
    if (err) return res.status(500).json({ erro: err.message });
    res.json({ id: result.insertId, nome });
  });
});

app.put('/api/empreiteiros/:id', verificarToken, (req, res) => {
  const { nome } = req.body;
  db.query(`UPDATE empreiteiros SET nome = ? WHERE id = ? AND userId = ?`, [nome, req.params.id, req.user.userId], (err) => {
    if (err) return res.status(500).json({ erro: err.message });
    res.json({ mensagem: 'Atualizado com sucesso' });
  });
});

app.delete('/api/empreiteiros/:id', verificarToken, (req, res) => {
  db.query(`DELETE FROM empreiteiros WHERE id = ? AND userId = ?`, [req.params.id, req.user.userId], (err) => {
    if (err) return res.status(500).json({ erro: err.message });
    res.json({ mensagem: 'Excluído com sucesso' });
  });
});

// Obras
app.get('/api/obras', verificarToken, (req, res) => {
  db.query(`SELECT * FROM obras WHERE userId = ?`, [req.user.userId], (err, rows) => {
    if (err) return res.status(500).json({ erro: err.message });
    const formatted = rows.map(o => ({ ...o, etapas: JSON.parse(o.etapas || '[]') }));
    res.json(formatted);
  });
});

app.post('/api/obras', verificarToken, (req, res) => {
  const { nome, areaExecucao, data, cep, endereco, complemento, valorTotal, empreiteiro, etapas } = req.body;
  const etapasStr = JSON.stringify(etapas || []);
  db.query(`INSERT INTO obras (userId, nome, areaExecucao, data, cep, endereco, complemento, valorTotal, empreiteiro, etapas) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [req.user.userId, nome, areaExecucao, data, cep, endereco, complemento, valorTotal, empreiteiro, etapasStr], (err, result) => {
      if (err) return res.status(500).json({ erro: err.message });
      res.json({ id: result.insertId });
    });
});

app.put('/api/obras/:id', verificarToken, (req, res) => {
  const { nome, areaExecucao, data, cep, endereco, complemento, valorTotal, empreiteiro, etapas } = req.body;
  const etapasStr = JSON.stringify(etapas || []);
  db.query(`UPDATE obras SET nome=?, areaExecucao=?, data=?, cep=?, endereco=?, complemento=?, valorTotal=?, empreiteiro=?, etapas=? WHERE id=? AND userId=?`,
    [nome, areaExecucao, data, cep, endereco, complemento, valorTotal, empreiteiro, etapasStr, req.params.id, req.user.userId], (err) => {
      if (err) return res.status(500).json({ erro: err.message });
      res.json({ mensagem: 'Atualizado com sucesso' });
    });
});

app.delete('/api/obras/:id', verificarToken, (req, res) => {
  db.query(`DELETE FROM obras WHERE id = ? AND userId = ?`, [req.params.id, req.user.userId], (err) => {
    if (err) return res.status(500).json({ erro: err.message });
    res.json({ mensagem: 'Excluído com sucesso' });
  });
});

// Medições
app.get('/api/medicoes', verificarToken, (req, res) => {
  db.query(`SELECT * FROM medicoes WHERE userId = ?`, [req.user.userId], (err, rows) => {
    if (err) return res.status(500).json({ erro: err.message });
    const formatted = rows.map(m => ({ ...m, etapas: JSON.parse(m.etapas || '[]') }));
    res.json(formatted);
  });
});

app.post('/api/medicoes', verificarToken, (req, res) => {
  const { empreiteiro, obraId, obraNome, data, valorTotalPagamento, etapas } = req.body;
  const etapasStr = JSON.stringify(etapas || []);
  db.query(`INSERT INTO medicoes (userId, empreiteiro, obraId, obraNome, data, valorTotalPagamento, etapas) VALUES (?, ?, ?, ?, ?, ?, ?)`,
    [req.user.userId, empreiteiro, obraId, obraNome, data, valorTotalPagamento, etapasStr], (err, result) => {
      if (err) return res.status(500).json({ erro: err.message });
      res.json({ id: result.insertId });
    });
});

app.delete('/api/medicoes/:id', verificarToken, (req, res) => {
  db.query(`DELETE FROM medicoes WHERE id = ? AND userId = ?`, [req.params.id, req.user.userId], (err) => {
    if (err) return res.status(500).json({ erro: err.message });
    res.json({ mensagem: 'Excluído com sucesso' });
  });
});

// Cronogramas
app.get('/api/cronogramas', verificarToken, (req, res) => {
  db.query(`SELECT dados FROM cronogramas WHERE userId = ?`, [req.user.userId], (err, rows) => {
    if (err) return res.status(500).json({ erro: err.message });
    res.json(rows.length > 0 ? JSON.parse(rows[0].dados) : {});
  });
});

app.post('/api/cronogramas', verificarToken, (req, res) => {
  const dadosStr = JSON.stringify(req.body);
  db.query(`REPLACE INTO cronogramas (userId, dados) VALUES (?, ?)`, [req.user.userId, dadosStr], (err) => {
    if (err) return res.status(500).json({ erro: err.message });
    res.json({ mensagem: 'Cronograma salvo com sucesso' });
  });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Servidor rodando na porta ${PORT}`);
});